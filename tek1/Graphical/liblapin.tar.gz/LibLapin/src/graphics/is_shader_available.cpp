// Jason Brillante "Damdoshi"
// Hanged Bunny Studio 2014-2015
//
// Bibliothèque Lapin

#include		"lapin_private.h"

bool			bunny_is_shader_available(void)
{
  return (sf::Shader::isAvailable());
}

