// Jason Brillante "Damdoshi"
// Hanged Bunny Studio 2014-2016
//
// Lapin library

#include		"lapin_private.h"

double			bunny_reset_clock(void)
{
  gl_bunny_current_time.restart();
  return (0);
}

