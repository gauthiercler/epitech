// Jason Brillante "Damdoshi"
// Hanged Bunny Studio 2014-2016
//
// Lapin library

#include		"lapin_private.h"

void			bunny_configuration_create_mode(bool			cmode)
{
  SmallConf::create_mode = cmode;
}

