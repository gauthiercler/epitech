// Jason Brillante "Damdoshi"
// Hanged Bunny Studio 2014-2016
//
// Lapin library

#include		"lapin_private.h"

t_bunny_configuration	*_bunny_read_lua(const char			*code,
					 t_bunny_configuration		*config)
{
  (void)code;
  (void)config;
  return (NULL);
}

