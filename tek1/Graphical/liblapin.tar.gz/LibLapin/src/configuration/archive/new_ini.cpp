// Jason Brillante "Damdoshi"
// Hanged Bunny Studio 2014-2016
//
// Bibliotheque Lapin

#include		"lapin_private.h"

t_bunny_ini		*bunny_new_ini(void)
{
  return (bunny_new_configuration());
}

