// Jason Brillante "Damdoshi"
// Hanged Bunny Studio 2014-2016
//
// Bibliotheque Lapin

#include		"lapin_private.h"

void			bunny_set_click_response(t_bunny_click	click)
{
  gl_callback.click = click;
}

