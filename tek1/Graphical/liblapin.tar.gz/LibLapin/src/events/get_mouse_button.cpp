// Jason Brillante "Damdoshi"
// Hanged Bunny Studio 2014-2016
//
// Bibliotheque Lapin

#include		"lapin_private.h"

const bool		*bunny_get_mouse_button(void)
{
  return (gl_button);
}
