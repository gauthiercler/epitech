// Jason Brillante "Damdoshi"
// Hanged Bunny Studio 2014-2016
//
// Bibliotheque Lapin

#include		"lapin_private.h"

const t_bunny_position	*bunny_get_mouse_position(void)
{
  return (&gl_mouse);
}
