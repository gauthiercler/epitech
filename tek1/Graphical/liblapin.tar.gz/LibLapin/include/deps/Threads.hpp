// Jason Brillante "Damdoshi"
// Hanged Bunny Studio 2014-2016
//
// HBSL - Threads

#ifndef				__HBSL_THREADS_HPP__
# define			__HBSL_THREADS_HPP__
# include			"Work.hpp"
# include			"Workers.hpp"
#endif	//			__HBSL_THREADS_HPP__
