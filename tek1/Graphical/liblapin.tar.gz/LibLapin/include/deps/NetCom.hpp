// Jason Brillante "Damdoshi"
// Pentacle Technologie 2009-2013
//
// BPT NetCom

#ifndef			__NETCOM_HPP__
# define		__NETCOM_HPP__
# include		"Communicator.hpp"
# include		"Server.hpp"
# include		"Client.hpp"
# include		"To.hpp"
#endif	//		__NETCOM_HPP__
