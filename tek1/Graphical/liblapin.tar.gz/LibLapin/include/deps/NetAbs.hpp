// Jason Brillante "Damdoshi"
// Hanged Bunny Studio 2014-2016
//
// LibLapin

#ifndef				__NETABS_HPP__
# define			__NETABS_HPP__
# include			"NetUnix.hpp"

namespace			bpt
{
  namespace			NetAbs
  {
    class			NetAbs : public NetUnix
    {};
  }
}

#endif	//			__NETABS_HPP__

