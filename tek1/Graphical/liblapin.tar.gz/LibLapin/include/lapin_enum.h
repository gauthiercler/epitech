/*
** Exists only because its existed from 1.0 to 1.6
*/

#ifndef			__LAPIN_ENUM_COMPAT_H__
# define		__LAPIN_ENUM_COMPAT_H__
# include		"lapin.h"
#endif	/*		__LAPIN_ENUM_COMPAT_H__	*/

