#!/bin/sh

man gcc | ./broadcast_client 127.0.0.1 5000
