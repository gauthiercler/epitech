/*
** MyName
** MyCompany 1970-2017
**
** BunnyProject
*/

#include		"bunny_project.h"

/* 800.0 pixels per seconds */
const double		bunny_move_speed = 800.0 / BUNNY_FREQUENCY;

/* 180 degree per seconds */
const double		bunny_rot_speed = 180.0 / BUNNY_FREQUENCY;
